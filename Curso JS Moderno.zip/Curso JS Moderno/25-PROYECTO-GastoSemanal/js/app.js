//Variables y Selectores
const formulario = document.querySelector('#agregar-gasto');
const gastoLista = document.querySelector('#gastos ul');


//Eventos
eventListeners();
function eventListeners() {
    document.addEventListener('DOMContentLoaded', preguntarPresupuesto);
    formulario.addEventListener('submit', agregarGasto);
}




// Classes
class Presupuesto {  // Clase de presupuesto, solo tiene en cuenta los valores que se muestran en la parte derecha de la interfa y el arreglo que mostrara los gastos.
    constructor(presupuesto) {
        this.presupuesto = Number(presupuesto);
        this.restante = Number(presupuesto);
        this.gastos = [];    // Declara gastos como un arreglo vacio en el constructor
    }

    nuevoGasto(gasto) {          // Esta funcion agregar el objeto gasto al arreglo, este objeto esta definido en la clase agregar gasto
        this.gastos = [...this.gastos, gasto];  // Usa el spread operator y le agrega a la copia del arreglo el objeto que se esta tomando como parametro
        this.calcularRestante();

    }

    calcularRestante() {

        const gastado = this.gastos.reduce((total, gasto) => total + gasto.cantidad, 0);
        this.restante = this.presupuesto - gastado;

    }

    eliminarGasto(id){

        this.gastos = this.gastos.filter(gasto => gasto.id !==id);
        this.calcularRestante();
        
    }
}

class UI {
    insertarPresupuesto(cantidad) {  // Este metodo trae al objeto de presupuesto y toma sus dos propiedades y las agrega a los campos HTML/

        //Extrayendo valores del Objeto cantidad que equivale a la instancia de objeto haciendo uso de destructuring
        const { presupuesto, restante } = cantidad;

        //Agregar al HTML
        document.querySelector('#total').textContent = presupuesto;
        document.querySelector('#restante').textContent = restante;



    }

    imprimirAlerta(mensaje, tipo) {
        // crear el div
        const divMensaje = document.createElement('DIV');
        divMensaje.classList.add('text-center', 'alert');

        if (tipo === 'error') {
            divMensaje.classList.add('alert-danger');
        } else {
            divMensaje.classList.add('alert-success');
        }

        //Mensaje de error
        divMensaje.textContent = mensaje;


        //Insertar en el HTML

        document.querySelector('.primario').insertBefore(divMensaje, formulario);


        setTimeout(() => {
            divMensaje.remove();
        }, 3000);
    }

    agregarGastoListado(gastos) {
        this.limpiarHTML();

        //Iterar sobre los gastos
        gastos.forEach(gasto => {  // Se itera el arreglo para acceder a cada instancia del objeto e ir creando el HTML con las propiedades del objeto
            const { cantidad, nombre, id } = gasto;

            // Crear un LI
            const nuevoGasto = document.createElement('Li');
            nuevoGasto.className = 'List-group-item d-flex justify-content-between align-items-center';
            nuevoGasto.dataset.id = id;


            console.log(nuevoGasto);

            //Agregar el HTML del gasto
            nuevoGasto.innerHTML = `${nombre} <span class="badge badge-primary badge-pill">$ ${cantidad}</span>`;

            //Boton para borrar el gasto

            const btnBorrar = document.createElement('button');
            btnBorrar.classList.add('btn', 'btn-danger', 'borrar-gasto');
            btnBorrar.innerHTML = 'Borrar &times'
            btnBorrar.onclick = () => {
                eliminarGasto(id);
            }
            nuevoGasto.appendChild(btnBorrar);


            //Agregar al HTML

            gastoLista.appendChild(nuevoGasto);

        });
    }

    limpiarHTML() {

        while (gastoLista.firstChild) {
            gastoLista.removeChild(gastoLista.firstChild)           //Revisa si el padre tiene hijos y los va removiendo a medida que comprueba esto, de esta manera limpia el HTML 
        }                                                                       // Cuando ya no hay hijos deja de ejecutarse.
    }

    actualizarRestante(restante) {
        document.querySelector('#restante').textContent = restante;
    }

    comprobarPresupuesto(presupuestoObj) {
        const { presupuesto, restante } = presupuestoObj;

        const restanteDiv = document.querySelector('.restante');

        //Comprobar 25%
        if ((presupuesto / 4) > restante) {
            restanteDiv.classList.remove('alert-success', 'alert-warning');
            restanteDiv.classList.add('alert-danger');
        } else if ((presupuesto / 2) > restante) {
            restanteDiv.classList.remove('alert-success');
            restanteDiv.classList.add('alert-warning');
        } else {
            restanteDiv.classList.remove('alert-danger', 'alert-warning');
            restanteDiv.classList.add('alert-success');

        }


        //Si el total es 0 o menor

        if (restante <= 0) {
            ui.imprimirAlerta('El presupuesto se ha agotado', 'error');
            formulario.querySelector('button[type="submit"]').disabled = true;
        }
    }
}


// Instanciar 
const ui = new UI();


let presupuesto; // Variable sin incializar se le asignara el valor que tome la instancia de la clase Presupuesto posterior a que se valide.

//Funciones


function preguntarPresupuesto() {
    const presupuestoUsuario = prompt('Cual es tu presupuesto?');




    if (presupuestoUsuario === '' || presupuestoUsuario === null || isNaN(presupuestoUsuario) || presupuestoUsuario <= 0) {
        window.location.reload();
    }


    //Presupuesto valido

    presupuesto = new Presupuesto(presupuestoUsuario); // Se crea la instancia de la clase presupuesto pasandole el presupueto digitado en el prompt como valor que tomara esta clase para 'presupuesto' y 'restante;


    ui.insertarPresupuesto(presupuesto);  // Se llama al metodo insertarPresupuesto y se le pasa la iteracion de la clase presupuesto como parametro.
}


//Agregar gastos

function agregarGasto(e) {  // Funcion que valida los campos y hace todo al clickear el boton de agregar que es un submit, aqui se llaman todas las funciones que se ejecutaran al undir agregar
    e.preventDefault();

    //Leer los datos del formulario
    const nombre = document.querySelector('#gasto').value;
    const cantidad = Number(document.querySelector('#cantidad').value);


    //Valida que los campos no esten vacios o sean validos y de esta forma llama al metodo de las alertas.

    if (nombre === '' || cantidad === '') {

        ui.imprimirAlerta('Ambos campos son obligatorios', 'error');

        return;

    } else if (cantidad <= 0 || isNaN(cantidad)) {
        ui.imprimirAlerta('Cantidad no valida', 'error')
        return;
    }

    // Generar un objeto con el gasto

    const gasto = { nombre, cantidad, id: Date.now() }  // Crea el objeto de gasto teniendo en cuenta el nombre y la cantidad que son los valores que se digitan en los campos de la interfaz


    //Agregar un nuevo gasto

    presupuesto.nuevoGasto(gasto);  // Llama a la funcion nuevo gasto de la clase presupuesto y le pasa como parametro el objeto gasto, para que esta lo tome y lo agregue al arreglo vacio


    ui.imprimirAlerta('Gasto Agregado Correctamente'); // Mensaje corrcecto


    //Imprimir los gastos
    const { gastos, restante } = presupuesto;

    ui.agregarGastoListado(gastos);

    ui.actualizarRestante(restante);

    ui.comprobarPresupuesto(presupuesto);

    // Reinicia el formulario

    formulario.reset();



}

function eliminarGasto(id){
    console.log(id);


    //Elimina los gastos del objeto
    presupuesto.eliminarGasto(id); 

    //Elimina los gastos del HTML
    const {gastos, restante} = presupuesto;
    ui.agregarGastoListado(gastos);

    ui.actualizarRestante(restante);

    ui.comprobarPresupuesto(presupuesto);

}





