const numero1 = 30;
const numero2 = 20;



let resultado;


// Suma
 
resultado = numero1 + numero2;



// Resta

resultado = numero1 - numero2;

// Multiplicacion

resultado = numero1 * numero2;


// Division

resultado = numero1 / numero2;

//Modulo

resultado = numero1 % numero2;




console.log(resultado);