class Cliente {    // Class declaration
    constructor(nombre, saldo){
         this.nombre = nombre;
         this.saldo = saldo;
    }

    mostrarInformacion() {
       return `Cliente: ${this.nombre}, tu saldo es de ${this.saldo}`
    }

    static bienvenida(){
       return `Bienvenido al cajero`
    }
}

//Herencia

class Empresa extends Cliente {
  constructor(nombre, saldo, telefono, categoria){
    super(nombre, saldo);
    this.telefono = telefono;
    this.categoria = categoria;
    
  }
  static bienvenida(){ //Reescribir un metodo nombrandolo de la misma forma
    return `Bienvenido al cajero de empresas`
 }
}


const juan = new Cliente ('Juan', 400);
const empresa = new Empresa('Apple', 2000, 3137714901, 'tecnologia');

console.log(empresa.mostrarInformacion());
console.log(Cliente.bienvenida());
console.log(Empresa.bienvenida());