
const puntaje = 1001;

if(puntaje == 1000){
   console.log('Si es igual...')
} else {
    console.log('No es igual')
}