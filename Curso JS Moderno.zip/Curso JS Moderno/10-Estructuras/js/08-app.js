const autenticado = true;

if (autenticado) {
    console.log('El usuario esta autenticado')
}




const puntaje = 350;


function revisarPuntaje() {
    if (puntaje > 400) {
        console.log('Excelente!!')
        return;
    }
    if (puntaje > 300) {
        console.log('Aspero papi')
        return;
    }
}

revisarPuntaje();
