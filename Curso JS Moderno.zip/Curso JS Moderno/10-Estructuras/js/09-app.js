const autenticado = true;
const puedePagar = true;

console.log( autenticado  ? puedePagar ? 'Si esta autenticado y puede pagar' : 'Si autenticado pero no puede pagar' : 'No esta autenticado' );

