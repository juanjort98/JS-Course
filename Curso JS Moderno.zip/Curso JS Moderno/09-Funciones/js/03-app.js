// alert('hubo un error...');

// prompt('Cual es tu edad');

console.log(parseInt('20'));


