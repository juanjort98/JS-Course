// Declaracion de Funcion (Function Declaration)

function sumar(){
    console.log(2+2);
}


sumar();
sumar();
sumar();


// Expresion de Funcion (Function Exoression)
const sumar2 = function(){
    console.log(3+3);
}

sumar2();

 