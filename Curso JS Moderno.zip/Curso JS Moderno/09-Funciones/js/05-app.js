function sumar(a, b){  //a y b son parametros (representativos)
    console.log(a + b);
}


sumar(2,3);  // 2 y 3 son argumentos (valores reales)
sumar(200,184);  
sumar(124,321);  


function saludar(nombre, apellido) {
    console.log(`Hola ${nombre} ${apellido}`);
}

saludar('Juan', 'Ramirez');
saludar();