// Declaracion de Funcion (Function Declaration)
sumar();
function sumar(){
    console.log(2+2);
}



 


// Expresion de Funcion (Function Exoression)
sumar2();
const sumar2 = function(){
    console.log(3+3);
}

 