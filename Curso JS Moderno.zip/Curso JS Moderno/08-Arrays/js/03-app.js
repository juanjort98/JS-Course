 const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio '];

 console.table(meses);



 // Cuanto mide el arreglo

 console.log(meses.length);
 
 for(let i = 0;  i < meses.length; i++ ) {
     console.log(meses[i]);
 }
