const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio '];

meses[0] = 'Nuevo Mes';
meses[7] = 'Ultimo mes';

console.table(meses);