const numero1 = 20;
const numero2 = "20";
const numero3 = 30;

// Operador mayor a...


console.log(numero1 > numero3);
console.log(numero3 > numero1);


// Operador menor a..

console.log(numero1 < numero3)