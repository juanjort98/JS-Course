const nombre = localStorage.getItem('nombre');
console.log(nombre);


const productoJSON = localStorage.getItem('producto');
console.log(JSON.parse(productoJSON));  // Parse lo convierte de nuevo a objeto 


const meses = localStorage.getItem('meses');
console.log(JSON.parse(meses));  // Parse lo convierte de nuevo a objeto 