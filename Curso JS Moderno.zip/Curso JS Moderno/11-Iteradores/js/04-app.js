let i = 1; // Inicializar el While


while (i <= 20) { // Condicion

    
    if (i % 2 === 0) {
        console.log(`El numero ${i} es par`)
    }
    else {
        console.log(`El numero ${i} es impar`)
    }

    i++; // Incremento
}