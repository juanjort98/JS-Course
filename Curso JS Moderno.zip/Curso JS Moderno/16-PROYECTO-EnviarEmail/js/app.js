document.addEventListener('DOMContentLoaded', function () {


    const email = {
        email: '',
        cc: '',
        asunto: '',
        mensaje: ''
    }


    console.log(email);

    // Seleccionar los elementos de la interfaz

    const inputEmail = document.querySelector('#email');
    const inputCC = document.querySelector('#cc');
    const inputAsunto = document.querySelector('#asunto');
    const inputMensaje = document.querySelector('#mensaje');
    const formulario = document.querySelector('#formulario');
    const btnSubmit = document.querySelector('#formulario button[type="submit"]')
    const btnReset = document.querySelector('#formulario button[type="reset"]')
    const spinner = document.querySelector("#spinner");


    // Asignar eventos
    inputEmail.addEventListener('input', validar);
    inputCC.addEventListener('blur', validar);
    inputAsunto.addEventListener('input', validar);
    inputMensaje.addEventListener('input', validar);
    formulario.addEventListener('submit', enviarEmail);

    btnReset.addEventListener('click', function (e) {
        e.preventDefault();
        resetFormulario();

    })

    function enviarEmail(e) {
        e.preventDefault();
        spinner.classList.add('flex');
        spinner.classList.remove('hidden');

        setTimeout(() => {
            spinner.classList.remove('flex');
            spinner.classList.add('hidden');

            // Reiniciar el objeto
            resetFormulario();

            // Crear una alerta
            const alertaExito = document.createElement('P');
            alertaExito.classList.add('bg-green-500', 'text-white', 'p-2', 'text-center', 'rounded-lg', 'mt-10', 'font-bold', 'text-sm', 'uppercase');
            alertaExito.textContent = 'mensaje enviado correctamente';

            formulario.appendChild(alertaExito);

            setTimeout(() => {
                alertaExito.remove();
            }, 3000);
        }, 3000);
    }

    function validar(e) {

        if (e.target.value.trim() === '' && e.target.id !== 'cc') {       //Trim elimina los espacios en blanco
            mostrarAlerta(`El Campo ${e.target.id} es obligatorio`, e.target.parentElement);
            email[e.target.name] = '';  //Limpia los valores del objeto que se eliminen del campo
            comprobarEmail();
            return;
        }

        if ((e.target.id === 'email' || e.target.id === 'cc') && !validarEmail(e.target.value)) {
            mostrarAlerta('El email no es valido', e.target.parentElement);   //Llama a la funcion mostrar alerta cuando el email no cumpla con la expresion regular
            email[e.target.name] = '';
            comprobarEmail();
            return;
        }

        limpiarAlerta(e.target.parentElement);


        // Asignar los valores
        email[e.target.name] = e.target.value.trim().toLowerCase();

        //Comprobar el objeto de email

        comprobarEmail();

    }


    function mostrarAlerta(mensaje, referencia) {

        limpiarAlerta(referencia);


        // Generar alerta en HTML

        const error = document.createElement('P');
        error.textContent = mensaje; // Cuando se va a anadir solo texto, se recomienda usar .textContent enves de innerHTML por motivos de seguridad
        error.classList.add('bg-red-600', 'text-white', 'p-2', 'text-center')
        // Inyectar el error al formulario

        referencia.appendChild(error);  // appendChild le anade el hijo al padre

        // formulario.innerHTML = error.innerHTML   //Limpiaria todo el contenido del DIV y lo reemplazaria con el parrafo que se esta agregando
    }

    function limpiarAlerta(referencia) {

        //Comprueba si ya existe una alerta
        const alerta = referencia.querySelector('.bg-red-600');  //referencia se limita al div en el cual esta el input, no en todo el documento como si se usara Document.query...
        if (alerta) {
            alerta.remove();
        }
    }

    function validarEmail(email) {
        const regex = /^\w+([.-_+]?\w+)*@\w+([.-]?\w+)*(\.\w{2,10})+$/
        const resultado = regex.test(email);
        return resultado;
    }

    // function comprobarEmail() {
           
 
        
    
    //     // if (Object.values(email).includes('') || email['cc'] !== '' && !validarEmail(email['cc'])) { //Object.values crea un nuevo arreglo a partir de los valores del objeto email, por ende al ser un arreglo puede usarse el array method includes
    //     //     btnSubmit.classList.add('opacity-50');
    //     //     btnSubmit.disabled = true;
    //     //     return;
    //     // }

    //     btnSubmit.classList.remove('opacity-50');
    //     btnSubmit.disabled = false;
    // }

    function comprobarEmail() {
        const obligatorio = ['email', 'asunto', 'mensaje'];  //Se crea un arreglo con los valores del objeto original que deben ser obligatorios
      
        if (
          obligatorio.every(valor => email[valor] !== '')  //El metodo every comprueba que cada uno de estos valores este en el objeto email, el restante que no esta en este arreglo podra estarlo
          // Valida que email[cc] puede estar vacio
        ) {
          btnSubmit.classList.remove('opacity-50');
          btnSubmit.disabled = false;
        } else {
          btnSubmit.classList.add('opacity-50');
          btnSubmit.disabled = true;
        }
      }

    function resetFormulario() {

        // Reiniciar el objeto

        email.email = '';
        email.asunto = '';
        email.mensaje = '';
        email.cc = '';

        formulario.reset();
        comprobarEmail();
    }

});