const producto = {
    nombre: "Monitor 20 Pulgadas",
    precio: 300,
    disponible: true
}

console.log(producto);

console.log(producto.nombre); //Mas comun
console.log(producto.precio); //Mas comun
console.log(producto.disponible); //Mas comun

console.log(producto['nombre']);

