const card = document.querySelectorAll('.card');
console.log(card);