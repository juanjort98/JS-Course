const btnFlotante = document.querySelector('.btn-flotante');
const footer = document.querySelector('.footer');


btnFlotante.addEventListener('click', mostrarOcultarFooter); // Evento que espera a que se presione el boton para ejecutar una funcion 



function mostrarOcultarFooter() {
    if (footer.classList.contains('activo')) {   //Verifica si ya esta la clase existente en el footer con el metodo contains
        footer.classList.remove('activo'); //Si ya esta dicha clase remueve la clase para ocultar el footer
        this.classList.remove('activo');     //this hace referencia a lo que mando a llamar a la funcion      
        this.textContent = 'Idioma y Moneda';                                                                  
    } else {
        footer.classList.add('activo');   //Si no esta dicha clase la añade al footer para que este se muestre al presionar el boton
        this.classList.add('activo');      
        this.textContent =  'X Cerrar';                           
    }


    console.log(footer.classList);
}