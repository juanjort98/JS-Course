const nav = document.querySelector('.navegacion');


// registrar un evento
nav.addEventListener('mouseenter', () => {
    console.log('entrando a la  nav');
    nav.style.backgroundColor = 'transparent';
})

nav.addEventListener('dblclick', () => {
    console.log('saliendo de la  nav');
    nav.style.backgroundColor = 'white';
})


// mousedown - similar al click
// click - doble click
// dblclick - doble click
// mouseup - cuando sueltas el mouse