const formulario  = document.querySelector('#formulario');


formulario.addEventListener('submit', validarFormulario);



function validarFormulario(e){

    e.preventDefault(); //previene la accion que realizaria el elemento por default

    console.log(e.target.action);

}
