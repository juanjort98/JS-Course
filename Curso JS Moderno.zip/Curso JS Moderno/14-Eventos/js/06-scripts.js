// Event Bubbling

const cardDiv = document.querySelector('.card');
const infoDiv = document.querySelector('.info');
const titulo = document.querySelector('.titulo');


cardDiv.addEventListener('click', e =>{
    e.stopPropagation()   //Evita el event Bubbling con este metodo,detiene que se propague el mismo evento
    console.log('click en card');
});

infoDiv.addEventListener('click', e=>{
    e.stopPropagation()
    console.log('click en info');
});

titulo.addEventListener('click', e=>{
    e.stopPropagation()
    console.log('click en titulo');
});