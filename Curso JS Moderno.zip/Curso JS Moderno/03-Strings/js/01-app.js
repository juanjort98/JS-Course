const producto = "Monitor de 20 \"";
const producto2 = String('Monitor 24"');
const producto3 = new String('Monitor 27 Pulgadas');

console.log(producto);
console.log(producto2);
console.log(producto3);