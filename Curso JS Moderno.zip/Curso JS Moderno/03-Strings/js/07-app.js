const producto = 'Monitor 20 Pulgadas ';

console.log(producto.toUpperCase());


console.log(producto.toLowerCase());


const email = "CORREO@CORREO.COM";

console.log(email.toLowerCase());




const precio = 300;

console.log(precio);
console.log(precio.toString());